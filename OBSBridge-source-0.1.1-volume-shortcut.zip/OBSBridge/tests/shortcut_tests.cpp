#include "../core/Shortcut.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <iostream>

int main() {
    using obs::UpDownShortcut;
    UpDownShortcut a;
    assert(!a.button(true, 1));
    assert(a.button(false, 1.2));
    assert(!a.button(true, 1.4)); assert(!a.button(false, 1.6)); // cooldown
    assert(!a.button(true, 4)); assert(a.button(false, 4.2));
    UpDownShortcut reverse;
    assert(!reverse.button(false, 1)); assert(!reverse.button(true, 1.2));
    assert(!reverse.button(false, 2.2)); // prior Up expired
    UpDownShortcut repeat;
    assert(!repeat.button(true, 1)); assert(!repeat.button(true, 1.1));
    assert(!repeat.button(false, 1.2)); // repeated Up cancels
    assert(!repeat.button(true, 3)); assert(repeat.button(false, 3.2));
    UpDownShortcut held;
    for (int i = 0; i < 20; ++i) assert(!held.button(true, 1 + i * .1));
    assert(!held.button(false, 3)); // held Up does not arm on its repeats
    UpDownShortcut locked;
    assert(!locked.button(true, 1)); assert(!locked.button(false, 1.2, false));
    assert(!locked.button(false, 1.3));
    assert(!locked.button(true, 2, false)); assert(!locked.button(false, 2.2));
    UpDownShortcut bounce;
    assert(!bounce.button(true, 1)); assert(!bounce.button(false, 1.001));
    UpDownShortcut invalid;
    assert(!invalid.button(true, NAN)); assert(!invalid.button(false, 1));
    assert(!invalid.button(true, 10)); assert(!invalid.button(false, 2));
    assert(!invalid.button(true, 3)); assert(invalid.button(false, 3.3));
    UpDownShortcut boundary;
    assert(!boundary.button(true, 1)); assert(boundary.button(false, 1.8));
    UpDownShortcut slow;
    assert(!slow.button(true, 1)); assert(!slow.button(false, 1.801));
    std::cout << "PASS: Up->Down, expiry, reverse, repeats, hold, cooldown, locked, bounce, time reset\n";
}
