"""Check actual .deb payloads, not just source-tree files. No extraction to disk."""
import io
import plistlib
import struct
import sys
import tarfile
from pathlib import Path, PurePosixPath


def payload(path):
    raw = Path(path).read_bytes()
    if raw[:8] != b"!<arch>\n":
        raise ValueError("not a Debian ar archive")
    offset = 8
    result = {}
    while offset < len(raw):
        header = raw[offset:offset + 60]
        if len(header) != 60 or header[-2:] != b"`\n":
            raise ValueError("invalid ar header")
        name = header[:16].decode("ascii").strip().rstrip("/")
        size = int(header[48:58])
        start = offset + 60
        if start + size > len(raw):
            raise ValueError("truncated ar member")
        if name.startswith("data.tar"):
            with tarfile.open(fileobj=io.BytesIO(raw[start:start + size])) as archive:
                for member in archive.getmembers():
                    if not member.isfile():
                        continue
                    key = PurePosixPath(member.name).as_posix().removeprefix("./")
                    result[key] = archive.extractfile(member).read()
        offset = start + size + size % 2
    return result


def check(path):
    files = payload(path)
    prefix = "var/jb/Library/"
    required = [
        "MobileSubstrate/DynamicLibraries/OBSBridge.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridge.plist",
        "MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib",
        "MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist",
        "PreferenceBundles/OBSBridgePrefs.bundle/OBSBridgePrefs",
        "PreferenceBundles/OBSBridgePrefs.bundle/Info.plist",
        "PreferenceBundles/OBSBridgePrefs.bundle/Root.plist",
        "PreferenceLoader/Preferences/OBSBridge.plist",
    ]
    missing = [prefix + name for name in required if prefix + name not in files]
    if missing:
        raise ValueError("missing packaged files: " + ", ".join(missing))
    daemon = plistlib.loads(files[prefix + required[1]])
    shortcut = plistlib.loads(files[prefix + required[3]])
    if daemon.get("Filter") != {"Executables": ["mediaserverd"]}:
        raise ValueError("incorrect media-service filter")
    if shortcut.get("Filter") != {"Bundles": ["com.apple.springboard"]}:
        raise ValueError("incorrect SpringBoard filter")
    for name in [required[0], required[2], required[4]]:
        raw = files[prefix + name]
        if raw[:4] != b"\xca\xfe\xba\xbe" or len(raw) < 8:
            raise ValueError("expected universal arm64/arm64e Mach-O: " + name)
        count = struct.unpack_from(">I", raw, 4)[0]
        archs = []
        for i in range(count):
            cpu, subtype, start, size, align = struct.unpack_from(">IIIII", raw, 8 + 20 * i)
            if start + size > len(raw) or raw[start:start + 4] != b"\xcf\xfa\xed\xfe":
                raise ValueError("invalid Mach-O slice: " + name)
            archs.append((cpu, subtype & 0xffffff))
        if (0x0100000c, 0) not in archs or (0x0100000c, 2) not in archs:
            raise ValueError("missing arm64/arm64e architecture: " + name)
    return len(files)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: check_deb.py PACKAGE.deb [...]")
    for name in sys.argv[1:]:
        try:
            count = check(name)
        except (ValueError, OSError, tarfile.TarError, struct.error) as error:
            raise SystemExit(f"PACKAGE CHECK FAILED: {name}: {error}")
        print(f"PASS: {Path(name).name}: {count} files; media engine + shortcut + settings payloads present")
