"""Synthetic package fixtures only; never install these on a device."""
import io
import plistlib
import struct
import tarfile
import tempfile
import unittest
from pathlib import Path

from check_deb import check


def macho(archs=(0, 2)):
    offset = 8 + len(archs) * 20
    headers = []
    slices = []
    for subtype in archs:
        data = struct.pack("<8I", 0xfeedfacf, 0x100000c, subtype, 6, 0, 0, 0, 0)
        headers.append(struct.pack(">5I", 0x100000c, subtype, offset, len(data), 0))
        slices.append(data)
        offset += len(data)
    return b"\xca\xfe\xba\xbe" + struct.pack(">I", len(archs)) + b"".join(headers + slices)


def files():
    prefix = "var/jb/Library/"
    plist = lambda value: plistlib.dumps(value, fmt=plistlib.FMT_BINARY)
    return {
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridge.dylib": macho(),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridge.plist": plist({"Filter": {"Executables": ["mediaserverd"]}}),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib": macho(),
        prefix + "MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist": plist({"Filter": {"Bundles": ["com.apple.springboard"]}}),
        prefix + "PreferenceBundles/OBSBridgePrefs.bundle/OBSBridgePrefs": macho(),
        prefix + "PreferenceBundles/OBSBridgePrefs.bundle/Info.plist": plist({}),
        prefix + "PreferenceBundles/OBSBridgePrefs.bundle/Root.plist": plist({}),
        prefix + "PreferenceLoader/Preferences/OBSBridge.plist": plist({}),
    }


def package(items):
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode="w:gz") as archive:
        for name, content in items.items():
            member = tarfile.TarInfo(name)
            member.size = len(content)
            archive.addfile(member, io.BytesIO(content))
    def ar(name, content):
        header = f"{name + '/':<16}{0:<12}{0:<6}{0:<6}{'100644':<8}{len(content):<10}`\n".encode("ascii")
        return header + content + (b"\n" if len(content) % 2 else b"")
    return b"!<arch>\n" + ar("debian-binary", b"2.0\n") + ar("data.tar.gz", data.getvalue())


class DebCheckerTest(unittest.TestCase):
    def run_check(self, raw):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic-test-only.deb"
            path.write_bytes(raw)
            return check(path)

    def test_complete_fixture(self):
        self.assertEqual(self.run_check(package(files())), 8)

    def test_missing_shortcut(self):
        items = files()
        del items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib"]
        with self.assertRaisesRegex(ValueError, "missing packaged files"):
            self.run_check(package(items))

    def test_wrong_filter(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.plist"] = plistlib.dumps({"Filter": {"Bundles": ["wrong"]}})
        with self.assertRaisesRegex(ValueError, "incorrect SpringBoard filter"):
            self.run_check(package(items))

    def test_arm64e_only_is_rejected(self):
        items = files()
        items["var/jb/Library/MobileSubstrate/DynamicLibraries/OBSBridgeSB.dylib"] = macho((2,))
        with self.assertRaisesRegex(ValueError, "missing arm64/arm64e"):
            self.run_check(package(items))

    def test_truncated_archive(self):
        with self.assertRaisesRegex(ValueError, "truncated ar member"):
            self.run_check(package(files())[:-20])


if __name__ == "__main__":
    unittest.main(verbosity=2)
