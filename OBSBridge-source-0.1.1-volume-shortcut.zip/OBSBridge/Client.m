#import "Client.h"
#import "Shared.h"
#include <notify.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <string.h>
#include <math.h>

NSString *OBCWiFiIP(void) {
    struct ifaddrs *list = NULL; NSString *ip = nil;
    if (!getifaddrs(&list)) {
        for (struct ifaddrs *p = list; p; p = p->ifa_next) {
            if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET || strcmp(p->ifa_name, "en0")) continue;
            char value[INET_ADDRSTRLEN];
            if (inet_ntop(AF_INET, &((struct sockaddr_in *)p->ifa_addr)->sin_addr, value, sizeof(value)))
                ip = [NSString stringWithUTF8String:value];
        }
        freeifaddrs(list);
    }
    return ip;
}
NSString *OBCPeerIP(void) {
    CFPreferencesAppSynchronize(OB_DOMAIN);
    id value = CFBridgingRelease(CFPreferencesCopyAppValue(CFSTR("PCIP"), OB_DOMAIN));
    return [value isKindOfClass:NSString.class] ? value : @"";
}
void OBCSavePeerIP(NSString *peer) {
    NSString *trimmed = [peer stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    CFPreferencesSetAppValue(CFSTR("PCIP"), (__bridge CFStringRef)(trimmed ?: @""), OB_DOMAIN);
    CFPreferencesAppSynchronize(OB_DOMAIN);
}
NSString *OBCURL(void) {
    NSString *ip = OBCWiFiIP();
    return ip ? [NSString stringWithFormat:@"tcp://%@:%d", ip, OB_PORT] : nil;
}
NSString *OBCSendCommand(BOOL enabled, NSString *peer) {
    NSString *ip = OBCWiFiIP();
    NSString *trimmed = [peer stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    struct in_addr address;
    if (enabled && (!ip || !trimmed || inet_pton(AF_INET, trimmed.UTF8String, &address) != 1))
        return @"请连接 Wi-Fi，并填写 OBS 电脑的局域网 IPv4（不是手机 IP）。";
    if (enabled) OBCSavePeerIP(trimmed);
    CFPreferencesSetAppValue(CFSTR("Enabled"), enabled ? kCFBooleanTrue : kCFBooleanFalse, OB_DOMAIN);
    CFPreferencesSetAppValue(CFSTR("BindIP"), (__bridge CFStringRef)(ip ?: @""), OB_DOMAIN);
    NSString *request = NSUUID.UUID.UUIDString;
    CFPreferencesSetAppValue(CFSTR("RequestID"), (__bridge CFStringRef)request, OB_DOMAIN);
    CFPreferencesSetAppValue(CFSTR("RequestDate"), (__bridge CFDateRef)[NSDate date], OB_DOMAIN);
    if (!CFPreferencesAppSynchronize(OB_DOMAIN)) return @"无法保存启动/停止命令。";
    NSDictionary *saved = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    if (![saved[@"RequestID"] isEqual:request])
        return @"命令没有出现在媒体服务使用的共享配置文件中。暂未发送通知，请提供快捷键状态文件进行检查。";
    chmod(OB_CONFIG.fileSystemRepresentation, 0644);
    if (notify_post(OB_NOTIFY) != NOTIFY_STATUS_OK) return @"命令已保存，但通知发送失败。";
    return nil;
}
NSString *OBCStatus(void) {
    NSDictionary *status = [NSDictionary dictionaryWithContentsOfFile:OB_STATUS];
    NSDate *date = status[@"Date"];
    if (![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow) > 8)
        return @"媒体服务没有新状态。菜单能打开只证明 SpringBoard 入口生效，不代表摄像头替换已生效。\n检查 mediaserverd 注入、状态文件权限；安装更新后需要重启用户空间。";
    NSString *text = status[@"Text"];
    return [text isKindOfClass:NSString.class] ? text : @"媒体服务状态格式错误。";
}
