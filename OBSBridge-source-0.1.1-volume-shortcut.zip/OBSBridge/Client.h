#pragma once
#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *OBCWiFiIP(void);
FOUNDATION_EXPORT NSString *OBCPeerIP(void);
FOUNDATION_EXPORT void OBCSavePeerIP(NSString *peer);
FOUNDATION_EXPORT NSString *OBCURL(void);
// nil = command saved and notification posted, NOT a receiver startup acknowledgement.
FOUNDATION_EXPORT NSString *OBCSendCommand(BOOL enabled, NSString *peer);
FOUNDATION_EXPORT NSString *OBCStatus(void);
