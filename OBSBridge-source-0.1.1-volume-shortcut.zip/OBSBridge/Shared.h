#pragma once
#define OB_DOMAIN CFSTR("local.xiaoguai.obsbridge")
#define OB_NOTIFY "local.xiaoguai.obsbridge.changed"
#define OB_CONFIG @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.plist"
#define OB_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.status.plist"
#define OB_PORT 5000
#define OB_VERSION @"0.1.1"
#define OB_SHORTCUT_STATUS @"/var/mobile/Library/Preferences/local.xiaoguai.obsbridge.shortcut.status.plist"
