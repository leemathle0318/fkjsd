# 检查记录（2026-10-11）

## 0.1.1 编译报错定点修复

- 用户提供的 GitHub 日志显示：OBSBridge 引擎完成链接/签名，OBSBridgeSB 在 `Shortcut.mm` 原第 62 行因 `UIApplication.windows` 的 iOS 15 弃用警告被当作错误而停止。截图中的链接器 obsolete 提示不是这次停止原因。
- 仅调整菜单窗口查找：枚举前台 `UIWindowScene.windows`，不再调用 `UIApplication.windows`；保留无场景时的原窗口创建回退与关闭后恢复窗口逻辑。未改音量快捷键、摄像头、音频、网络、版本号或工作流，也未关闭弃用警告。
- 修复后的静态结构/回归检查共 6 项通过；合成 deb 检查 5 项通过；ZIP 发现与版本选择检查通过；此前编译的快捷键与音频核心测试程序重新运行通过。
- 本机是 Windows，未执行修复后的 iOS 编译，尚不能宣称新 deb 已生成；需要在 GitHub 启动新的编译。实际音量按键、菜单和替换/混音仍待真机验证。

## 0.1.1 音量快捷键更新

- `tests/shortcut_tests.cpp`：在本机以 C++17、`-Wall -Wextra -Werror -O2` 编译并运行通过，覆盖上→下、超时、反序、重复/长按观察、冷却、锁屏条件、抖动和时间回退。这里的锁屏条件是可移植识别器输入，不是实际 iOS 锁屏测试。
- `tests/check_project.py`：新增 SpringBoard 模块检查，共 5 项通过。
- `tests/test_deb_checker.py`：5 项合成测试包用例通过，覆盖有效结构、缺快捷键模块、错误进程过滤、仅 arm64e（缺 8 Plus 所需 arm64）和损坏 ar 包。这些合成包不含可运行插件，不可安装。
- 已用新打包检查器读取用户实际的 0.1.0 包，按预期报告缺少 OBSBridgeSB.dylib / plist，证实旧包没有快捷键模块。
- 原音频时间线测试继续通过。
- 0.1.1 ZIP/工作流解析检查通过；根目录、子目录、改名 ZIP、缺文件/恶意路径/符号链接、多份包、只有旧 0.1.0 包，以及同时保留旧包和新包的选择均完成本机测试。工作流会跳过 0.1.0，不静默编译旧入口。
- **0.1.1 的 Objective-C/Objective-C++ iOS 编译、SpringBoard 挂接、UIAlert 菜单、实际按键和摄像头/混音效果尚未执行真机测试。**
- 不依赖设置菜单的快捷入口已实现于源码；并未宣称查明/修好了原 PreferenceLoader 的设置入口加载故障。

以下为此前的协议与源码检查记录，不能视为 0.1.1 完整真机验收。

执行环境：Windows，Python 3.12.1，Zig 0.13.0 的 C++ 编译器（仅测试可移植核心），电脑端 FFmpeg/ffprobe 9.0.1。

| 检查 | 实际结果 |
|---|---|
| `core/Timeline.cpp` + `tests/timeline_tests.cpp`，C++17、`-Wall -Wextra -Werror -O2` | 编译成功，测试程序通过；测试断言明确保持开启 |
| float32 / int16、交错/分离通道、增益、限幅、44.1k 输出重采样、空缓冲、重置、边界、NaN、并发 | 通过可移植核心测试 |
| `tests/check_project.py` | 4 个静态结构测试通过；包括 plist 解析和系统进程过滤规则 |
| `tests/test_transport.py` | 1 个本机回环 TCP 测试通过；每次读取 137 字节，重新收到完整 MPEG-TS，ffprobe 确认 H.264 + AAC 48kHz |
| FFmpeg 7.1.5 源码下载与 SHA-256 | 实际下载核对：`de668509caf9e35e3cd162473441fdb29538c6d96ed080292b3cf9e6fc5d558f` |
| Theos / SDK 固定提交与 iPhoneOS16.5 SDK 目录 | 已核对官方仓库存在 |
| GitHub 工作流 YAML、FFmpeg 构建脚本与内嵌 Shell 步骤 | 通过 YAML 解析与 bashlex 静态语法解析；未实际执行 macOS 构建 |
| 更新后的源码目录定位 | 已在临时目录验证：源码位于仓库根目录、位于 OBSBridge 子目录、缺少 core/Timeline.cpp 三种情况；前两种正确定位，第三种明确报错 |
| 单 ZIP 自动解压 | 已验证仅上传 ZIP、ZIP 加旧零散源码均正确解压定位；缺文件、路径穿越、符号链接 ZIP 均被拒绝。解压后的真实源码静态结构检查通过 |
| ZIP 按内容识别 | 已验证重命名（含中文/空格/下载序号）、放入子目录、大写 ZIP 扩展名；未上传 ZIP 时明确报错并显示空列表，多份不明确源码包时拒绝猜测 |
| `.github/workflows/build-deb.yml` / iOS 编译 | 未在 GitHub 或 macOS 上执行，不代表编译成功 |
| arm64/arm64e 注入、系统沙盒、iOS 15.0–16.6 真机、TikTok 远端画面与声音 | 未测试 |

这些结果不证明完整插件可运行。不要将核心测试、协议测试或打包配置称为完成了全版本系统级摄像头替换。
